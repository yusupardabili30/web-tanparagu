<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lock Screen - {{ $kegiatan->kegiatan_name }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <!-- IMPORT CSS LOGIN + PROFIL -->
    <link rel="stylesheet" href="{{ asset('build/css/login.min.css?v=' . time()) }}">
    <link rel="stylesheet" href="{{ asset('build/css/profil.min.css?v=' . time()) }}">
    <style>
        /* Hilangkan semua rounded */
        .no-radius,
        .no-radius * {
            border-radius: 0 !important;
        }
    </style>
</head>

<body>
    <div class="auth-container no-radius">
        <!-- Bagian Kiri: Carousel + BG Baduy -->
        <div class="info-section baduy-bg no-radius">
            <div class="carousel-container" style="position: relative; z-index: 1;">
                <div class="carousel-content">

                    <h1 class="system-name"> <!-- margin-bottom: 0 -->
                        <img src="{{ asset('build/images/logobgtkPutih.png') }}"
                            class="system-logo"
                            style="width: 250px; height: auto; margin-bottom: 10px;"> <!-- margin-bottom kecil -->
                    </h1>

                    <div id="infoCarousel" class="carousel slide" data-bs-ride="carousel" style="margin-bottom: 77px;">

                        <div class=" carousel-indicators">
                            <button type="button" data-bs-target="#infoCarousel" data-bs-slide-to="0" class="active"></button>
                            <button type="button" data-bs-target="#infoCarousel" data-bs-slide-to="1"></button>
                            <button type="button" data-bs-target="#infoCarousel" data-bs-slide-to="2"></button>
                        </div>

                        <div class="carousel-inner">

                            <div class="carousel-item active">
                                <img src="{{ asset('images/1.jpg') }}" class="carousel-image">
                                <div class="carousel-caption">
                                    <h5>Kolaborasi Tim</h5>
                                    <p>Bekerja sama untuk mencapai tujuan bersama</p>
                                </div>
                            </div>

                            <div class="carousel-item">
                                <img src="{{ asset('images/2.jpg') }}" class="carousel-image">
                                <div class="carousel-caption">
                                    <h5>Teknologi Modern</h5>
                                    <p>Menggunakan teknologi terkini untuk solusi terbaik</p>
                                </div>
                            </div>

                            <div class="carousel-item">
                                <img src="{{ asset('images/3.jpg') }}" class="carousel-image">
                                <div class="carousel-caption">
                                    <h5>Diskusi Produktif</h5>
                                    <p>Berbagi ide untuk inovasi yang lebih baik</p>
                                </div>
                            </div>

                        </div>

                        <button class="carousel-control-prev" type="button" data-bs-target="#infoCarousel" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon"></span>
                        </button>

                        <button class="carousel-control-next" type="button" data-bs-target="#infoCarousel" data-bs-slide="next">
                            <span class="carousel-control-next-icon"></span>
                        </button>

                    </div>

                </div>
            </div>
        </div>

        <!-- Bagian Kanan - Form Login (UPDATED DESIGN) -->
        <div class="login-section" style="margin-top:40px;">
            <div class="login-form-container">

                <div class="login-logo">
                    <h2 class="login-title">
                        <img src="{{ asset('build/images/tanparagu.png') }}" class="login-title-icon">
                    </h2>
                </div>

                <p class="login-subtitle"
                    style="margin-bottom: 10px; font-size: 22px; font-weight: 600; text-align:center; width:100%;">
                    Silahkan Masuk
                </p>

                <!-- Info Kegiatan Aktif -->
                <div class="kegiatan-info mb-3">
                    <h6 class="mb-1 text-primary">
                        <i class="ri-calendar-event-line me-1"></i> Kegiatan Aktif:
                    </h6>
                    <h5 class="mb-2">{{ $kegiatan->kegiatan_name }}</h5>
                    <small class="text-muted">
                        <i class="ri-calendar-2-line me-1"></i>
                        Periode: {{ date('d/m/Y', strtotime($kegiatan->start_date)) }}
                        -
                        {{ date('d/m/Y', strtotime($kegiatan->end_date)) }}
                    </small>
                </div>

                <!-- Form Login -->
                <form id="login-form" method="POST">
                    @csrf
                    <!-- Kirim kegiatan_id ASLI (decoded) -->
                    <input type="hidden" id="kegiatan_id" name="kegiatan_id" value="{{ $kegiatan_id }}">

                    <!-- Field NIP -->
                    <div class="mb-4">
                        <label class="form-label">
                            <i></i> Nomor Induk Pegawai (NIP)
                        </label>
                        <input type="text" name="nip" id="nip" class="form-control"
                            value="{{ old('nip', session('preserve_nip') ?? '') }}"
                            placeholder="Masukkan 18 digit NIP Anda"
                            required
                            autofocus
                            maxlength="18"
                            pattern="\d{18}"
                            title="Masukkan 18 digit NIP">
                        <small class="form-text text-muted mt-1">Contoh: 197010021990092010</small>
                    </div>

                    <!-- Field Token -->
                    <div class="mb-4">
                        <label class="form-label">
                            <i></i> Masukkan Token Kegiatan
                        </label>
                        <div class="input-group">
                            <input type="password" name="token" id="tokenInput"
                                class="form-control"
                                value="{{ old('token', '') }}"
                                placeholder="Masukkan token yang diberikan"
                                required>
                            <span class="input-group-text password-toggle" onclick="togglePassword()">
                                <i class="ri-eye-fill" id="passwordIcon"></i>
                            </span>
                        </div>
                        <small class="form-text text-muted mt-1">Token diberikan oleh administrator kegiatan</small>
                    </div>

                    <!-- Submit Button -->
                    <div class="d-grid mt-4">
                        <button type="submit" class="btn btn-login text-white py-2" id="submitBtn" style="font-size:15px;">
                            <i class="ri-login-box-line me-1"></i> Masuk ke Sistem
                        </button>
                    </div>
                </form>

                <!-- Logo Partner -->
                <div class="photo-gallery mt-4">
                    <img src="{{ asset('images/logoPendidikan.png') }}" class="gallery-photo" alt="Kemdikbud">
                    <img src="{{ asset('images/logoRamah.png') }}" class="gallery-photo" alt="Ramah Anak">
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Registrasi -->
    <div class="modal fade" id="registerModal" tabindex="-1" aria-labelledby="registerModalLabel" aria-hidden="true" data-bs-backdrop="static">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <!-- Modal Body -->
                <div class="modal-body">
                    <div class="alert alert-info mb-4">
                        <div class="d-flex align-items-center">
                            <i class="ri-information-line fs-4 me-3"></i>
                            <div>
                                <h6 class="mb-1">NIP Belum Terdaftar</h6>
                                <p class="mb-0" id="modal-info-text">
                                    <!-- Akan diisi oleh JavaScript -->
                                </p>
                            </div>
                        </div>
                    </div>

                    <form id="register-form">
                        @csrf
                        <!-- Data akan diisi oleh JavaScript -->
                        <input type="hidden" id="reg_nip" name="nip">
                        <input type="hidden" id="reg_kegiatan_id" name="kegiatan_id">
                        <input type="hidden" id="reg_token" name="token">

                        <div class="row">
                            <!-- Data Identitas -->
                            <div class="col-md-6 mb-3">
                                <label class="form-label">NIK</label>
                                <input type="text" name="nik" class="form-control"
                                    placeholder="16 digit NIK"
                                    maxlength="16">
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">NUPTK</label>
                                <input type="text" name="nuptk" class="form-control"
                                    placeholder="16 digit NUPTK"
                                    maxlength="16">
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">NPWP</label>
                                <input type="text" name="npwp" class="form-control"
                                    placeholder="15 digit NPWP"
                                    maxlength="20">
                            </div>

                            <!-- Data Pribadi -->
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-field">NAMA LENGKAP</label>
                                <input type="text" name="nama" class="form-control"
                                    placeholder="Nama lengkap"
                                    required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label required-field">JENIS KELAMIN</label>
                                <select name="jenis_kelamin" class="form-control" required>
                                    <option value="">Pilih Jenis Kelamin</option>
                                    <option value="L">LAKI-LAKI</option>
                                    <option value="P">PEREMPUAN</option>
                                </select>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label required-field">TEMPAT LAHIR</label>
                                <input type="text" name="tempat_lahir" class="form-control"
                                    placeholder="Kota tempat lahir"
                                    required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label required-field">TANGGAL LAHIR</label>
                                <input type="date" name="tgl_lahir" class="form-control" required>
                            </div>

                            <!-- Data Jabatan -->
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-field">PANGKAT/JABATAN</label>
                                <select name="pangkat_jabatan_id" class="form-control" required>
                                    <option value="">Pilih Pangkat/Jabatan</option>
                                    @foreach($pangkatJabatans as $pangkatJabatan)
                                    <option value="{{ $pangkatJabatan->pangkat_jabatan_id }}">
                                        {{ $pangkatJabatan->jenjang_jabatan }}
                                        @if($pangkatJabatan->pangkat)
                                        - {{ $pangkatJabatan->pangkat }}
                                        @endif
                                        @if($pangkatJabatan->golongan_ruang)
                                        ({{ $pangkatJabatan->golongan_ruang }})
                                        @endif
                                    </option>
                                    @endforeach
                                </select>
                            </div>

                            <!-- Kontak -->
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-field">EMAIL</label>
                                <input type="email" name="email" class="form-control"
                                    placeholder="email@contoh.com"
                                    required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label required-field">NOMOR HP</label>
                                <input type="text" name="no_hp" class="form-control"
                                    placeholder="081234567890"
                                    required>
                            </div>

                            <!-- Data Tambahan -->
                            <div class="col-md-6 mb-3">
                                <label class="form-label">AGAMA</label>
                                <select name="agama" class="form-control">
                                    <option value="">Pilih Agama</option>
                                    <option value="Islam">Islam</option>
                                    <option value="Kristen">Kristen</option>
                                    <option value="Katolik">Katolik</option>
                                    <option value="Hindu">Hindu</option>
                                    <option value="Buddha">Buddha</option>
                                    <option value="Konghucu">Konghucu</option>
                                </select>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">PENDIDIKAN TERAKHIR</label>
                                <input type="text" name="pendidikan" class="form-control"
                                    placeholder="Contoh: S1 Pendidikan Matematika">
                            </div>

                            <!-- Alamat Rumah -->
                            <div class="col-12 mb-3">
                                <label class="form-label">ALAMAT RUMAH</label>
                                <textarea name="alamat_rumah" class="form-control" rows="2"
                                    placeholder="Alamat lengkap tempat tinggal"></textarea>
                            </div>

                            <!-- KOTA -->
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-field">KOTA</label>
                                <select name="kota_id" class="form-control" id="kotaSelect" required>
                                    <option value="">Pilih Kota</option>
                                    @foreach($kotas as $kota)
                                    <option value="{{ $kota->kota_id }}">
                                        {{ $kota->nama_kota }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>

                            <!-- Sekolah/Instansi -->
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-field">SEKOLAH/INSTANSI</label>

                                <!-- Pilihan: Sekolah dari database atau input manual -->
                                <div class="mb-2">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="sekolah_option" id="optionSekolah" value="sekolah" checked>
                                        <label class="form-check-label" for="optionSekolah">Pilih Sekolah</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="sekolah_option" id="optionManual" value="manual">
                                        <label class="form-check-label" for="optionManual">Input Manual</label>
                                    </div>
                                </div>

                                <!-- Dropdown Sekolah -->
                                <div id="sekolahDropdownSection" class="mt-2">
                                    <div class="input-group">
                                        <select name="sekolah_id" class="form-control" id="sekolahSelect">
                                            <option value="">Pilih Sekolah</option>
                                            @foreach($sekolahs as $sekolah)
                                            <option value="{{ $sekolah->sekolah_id }}"
                                                data-nama="{{ $sekolah->nama_sekolah }}"
                                                data-npsn="{{ $sekolah->npsn }}"
                                                data-alamat="{{ $sekolah->alamat }}">
                                                {{ $sekolah->nama_sekolah }}
                                                @if($sekolah->npsn)
                                                (NPSN: {{ $sekolah->npsn }})
                                                @endif
                                            </option>
                                            @endforeach
                                        </select>
                                        <button class="btn btn-outline-primary" type="button" id="openSearchModalBtn">
                                            <i class="ri-search-line"></i>
                                        </button>
                                    </div>

                                    <!-- Info sekolah yang dipilih -->
                                    <div id="sekolahInfo" class="mt-2 p-2 bg-light rounded d-none">
                                        <small>
                                            <i class="ri-building-2-line me-1"></i>
                                            <span id="selectedSekolahName"></span>
                                            <br>
                                            <i class="ri-map-pin-line me-1"></i>
                                            <span id="selectedSekolahAlamat"></span>
                                        </small>
                                    </div>
                                </div>

                                <!-- Input Manual Instansi -->
                                <div id="instansiManualSection" class="mt-2 d-none">
                                    <input type="text" name="instansi" class="form-control" id="instansiInput"
                                        placeholder="Nama instansi/lembaga tempat bertugas">
                                    <small class="text-muted">Isi jika sekolah tidak ada dalam daftar</small>
                                </div>
                            </div>

                            <!-- Alamat Kantor -->
                            <div class="col-12 mb-3">
                                <label class="form-label">ALAMAT KANTOR</label>
                                <textarea name="alamat_kantor" class="form-control" rows="2"
                                    placeholder="Alamat lengkap tempat kerja"></textarea>
                            </div>

                            <div class="col-md-6 mb-4">
                                <label class="form-label">NOMOR REKENING</label>
                                <input type="text" name="no_rekening" class="form-control"
                                    placeholder="Nomor rekening bank">
                            </div>
                        </div>

                        <!-- Informasi Form -->
                        <div class="alert alert-warning">
                            <div class="d-flex align-items-center">
                                <i class="ri-alert-line me-3"></i>
                                <div>
                                    <h6 class="mb-1">Perhatian!</h6>
                                    <p class="mb-0">
                                        Data yang ditandai dengan <span class="text-danger">*</span> wajib diisi.
                                        Pastikan data yang dimasukkan akurat dan valid.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- Modal Footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="ri-close-line me-2"></i> BATAL
                    </button>
                    <button type="button" class="btn btn-primary" id="submit-register">
                        <i class="ri-save-line me-2"></i> SIMPAN DATA
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Search Sekolah -->
    <div class="modal fade" id="searchSekolahModal" tabindex="-1" aria-labelledby="searchSekolahModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="searchSekolahModalLabel">Cari Sekolah</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <div class="input-group">
                            <input type="text" id="modalSearchInput" class="form-control"
                                placeholder="Masukkan nama sekolah, NPSN, atau alamat...">
                            <button class="btn btn-primary" type="button" id="modalSearchBtn">
                                <i class="ri-search-line"></i> Cari
                            </button>
                        </div>
                        <small class="text-muted">Masukkan minimal 2 karakter untuk pencarian</small>
                    </div>

                    <div id="modalSearchLoading" class="d-none text-center my-3">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="mt-2">Mencari sekolah...</p>
                    </div>

                    <div id="searchResults" class="mt-3" style="max-height: 300px; overflow-y: auto;">
                        <div class="text-center text-muted">
                            <i class="ri-search-line fs-4"></i>
                            <p class="mt-2">Masukkan kata kunci untuk mencari sekolah</p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ============================================
        // 1. FUNGSI UTAMA
        // ============================================

        // Toggle password visibility
        function togglePassword() {
            const input = document.getElementById('tokenInput');
            const icon = document.getElementById('passwordIcon');

            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('ri-eye-fill', 'ri-eye-off-fill');
            } else {
                input.type = 'password';
                icon.classList.replace('ri-eye-off-fill', 'ri-eye-fill');
            }
        }

        // Format NIP input (hanya angka, maks 18 digit)
        document.getElementById('nip')?.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 18) {
                value = value.substring(0, 18);
            }
            e.target.value = value;
        });

        // Format No HP input (hanya angka)
        document.querySelector('input[name="no_hp"]')?.addEventListener('input', function(e) {
            e.target.value = e.target.value.replace(/\D/g, '');
        });

        // SweetAlert configuration
        const showAlert = (type, title, message) => {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer);
                    toast.addEventListener('mouseleave', Swal.resumeTimer);
                }
            });

            Toast.fire({
                icon: type,
                title: message
            });
        };

        // ============================================
        // 2. FUNGSI SEKOLAH
        // ============================================

        // Toggle antara pilihan sekolah dan input manual
        document.querySelectorAll('input[name="sekolah_option"]').forEach(radio => {
            radio.addEventListener('change', function(e) {
                const sekolahDropdownSection = document.getElementById('sekolahDropdownSection');
                const instansiManualSection = document.getElementById('instansiManualSection');
                const sekolahSelect = document.getElementById('sekolahSelect');
                const instansiInput = document.getElementById('instansiInput');

                // Reset validasi
                sekolahSelect.classList.remove('is-invalid');
                instansiInput.classList.remove('is-invalid');

                if (e.target.value === 'sekolah') {
                    // Tampilkan dropdown sekolah, sembunyikan input manual
                    sekolahDropdownSection.classList.remove('d-none');
                    instansiManualSection.classList.add('d-none');
                    instansiInput.value = '';
                } else {
                    // Tampilkan input manual, sembunyikan dropdown sekolah
                    sekolahDropdownSection.classList.add('d-none');
                    instansiManualSection.classList.remove('d-none');
                    sekolahSelect.value = '';
                    document.getElementById('sekolahInfo').classList.add('d-none');
                }
            });
        });

        // Handle sekolah dropdown change (menampilkan info)
        document.getElementById('sekolahSelect')?.addEventListener('change', function(e) {
            const sekolahId = e.target.value;
            const selectedOption = e.target.options[e.target.selectedIndex];
            const sekolahInfo = document.getElementById('sekolahInfo');
            const sekolahName = document.getElementById('selectedSekolahName');
            const sekolahAlamat = document.getElementById('selectedSekolahAlamat');

            // Reset validasi
            this.classList.remove('is-invalid');

            if (!sekolahId) {
                sekolahInfo.classList.add('d-none');
            } else {
                const sekolahNama = selectedOption.getAttribute('data-nama');
                const sekolahAlamatText = selectedOption.getAttribute('data-alamat');

                sekolahName.textContent = sekolahNama;
                sekolahAlamat.textContent = sekolahAlamatText || 'Alamat tidak tersedia';
                sekolahInfo.classList.remove('d-none');

                // Pastikan radio button "sekolah" terpilih
                document.getElementById('optionSekolah').checked = true;
                document.getElementById('optionSekolah').dispatchEvent(new Event('change'));
            }
        });

        // Function untuk memilih sekolah dari modal search
        function handlePilihSekolah(sekolahId, sekolahNama, sekolahAlamat) {
            console.log('Memilih sekolah:', sekolahId, sekolahNama);

            // 1. Pilih radio button sekolah
            const sekolahOption = document.getElementById('optionSekolah');
            sekolahOption.checked = true;
            sekolahOption.dispatchEvent(new Event('change'));

            // 2. Update dropdown sekolah
            const sekolahSelect = document.getElementById('sekolahSelect');

            // Cek apakah sekolah sudah ada di dropdown
            let optionExists = false;
            for (let i = 0; i < sekolahSelect.options.length; i++) {
                if (sekolahSelect.options[i].value === sekolahId) {
                    optionExists = true;
                    break;
                }
            }

            // Jika belum ada, tambahkan option baru
            if (!optionExists) {
                const newOption = new Option(
                    `${sekolahNama}`,
                    sekolahId,
                    true,
                    true
                );
                newOption.setAttribute('data-nama', sekolahNama);
                newOption.setAttribute('data-alamat', sekolahAlamat || '');
                sekolahSelect.add(newOption);
            }

            // Set value dropdown
            sekolahSelect.value = sekolahId;

            // 3. Update info sekolah
            const sekolahName = document.getElementById('selectedSekolahName');
            const sekolahAlamatSpan = document.getElementById('selectedSekolahAlamat');
            const sekolahInfo = document.getElementById('sekolahInfo');

            sekolahName.textContent = sekolahNama;
            sekolahAlamatSpan.textContent = sekolahAlamat || 'Alamat tidak tersedia';
            sekolahInfo.classList.remove('d-none');

            // 4. Trigger change event
            sekolahSelect.dispatchEvent(new Event('change'));

            console.log('Sekolah berhasil dipilih:', sekolahSelect.value);
        }

        // ============================================
        // 3. MODAL SEARCH SEKOLAH
        // ============================================

        // Open search sekolah modal
        document.getElementById('openSearchModalBtn')?.addEventListener('click', function() {
            const searchModal = new bootstrap.Modal(document.getElementById('searchSekolahModal'));
            searchModal.show();
        });

        // Search button in modal
        document.getElementById('modalSearchBtn')?.addEventListener('click', function() {
            const keyword = document.getElementById('modalSearchInput').value.trim();
            if (keyword.length >= 2) {
                searchSekolahModal(keyword);
            } else {
                showAlert('info', 'Pencarian', 'Masukkan minimal 2 karakter');
            }
        });

        // Enter key in search input
        document.getElementById('modalSearchInput')?.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const keyword = this.value.trim();
                if (keyword.length >= 2) {
                    searchSekolahModal(keyword);
                } else {
                    showAlert('info', 'Pencarian', 'Masukkan minimal 2 karakter');
                }
            }
        });

        // Function untuk search sekolah di modal
        function searchSekolahModal(keyword) {
            const searchResults = document.getElementById('searchResults');
            const loadingIndicator = document.getElementById('modalSearchLoading');

            loadingIndicator.classList.remove('d-none');
            searchResults.innerHTML = '';

            fetch(`/api/search-sekolah?keyword=${encodeURIComponent(keyword)}`, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    loadingIndicator.classList.add('d-none');

                    if (data.success && data.data && data.data.length > 0) {
                        let resultsHTML = '';
                        data.data.forEach(sekolah => {
                            resultsHTML += `
                        <div class="card mb-2 sekolah-item">
                            <div class="card-body">
                                <h6 class="card-title mb-1">${sekolah.nama_sekolah}</h6>
                                ${sekolah.npsn ? `<p class="card-text mb-1"><small><strong>NPSN:</strong> ${sekolah.npsn}</small></p>` : ''}
                                ${sekolah.alamat ? `<p class="card-text mb-1"><small><i class="ri-map-pin-line"></i> ${sekolah.alamat}</small></p>` : ''}
                                <button class="btn btn-sm btn-primary mt-2 pilih-sekolah-btn" 
                                        data-id="${sekolah.sekolah_id}"
                                        data-nama="${sekolah.nama_sekolah}"
                                        data-alamat="${sekolah.alamat || ''}">
                                    <i class="ri-check-line"></i> Pilih Sekolah Ini
                                </button>
                            </div>
                        </div>`;
                        });
                        searchResults.innerHTML = resultsHTML;
                    } else {
                        searchResults.innerHTML = `
                    <div class="text-center text-muted py-4">
                        <i class="ri-search-line fs-4"></i>
                        <p class="mt-2">Sekolah tidak ditemukan</p>
                    </div>`;
                    }
                })
                .catch(error => {
                    console.error('Error searching sekolah:', error);
                    loadingIndicator.classList.add('d-none');
                    searchResults.innerHTML = `
                <div class="text-center text-danger py-4">
                    <i class="ri-error-warning-line fs-4"></i>
                    <p class="mt-2">Gagal mencari sekolah. Silakan coba lagi.</p>
                </div>`;
                });
        }

        // Event delegation untuk tombol pilih sekolah di modal
        document.getElementById('searchResults')?.addEventListener('click', function(e) {
            if (e.target.classList.contains('pilih-sekolah-btn') ||
                e.target.closest('.pilih-sekolah-btn')) {

                const button = e.target.classList.contains('pilih-sekolah-btn') ?
                    e.target : e.target.closest('.pilih-sekolah-btn');

                const sekolahId = button.getAttribute('data-id');
                const sekolahNama = button.getAttribute('data-nama');
                const sekolahAlamat = button.getAttribute('data-alamat');

                // Pilih sekolah
                handlePilihSekolah(sekolahId, sekolahNama, sekolahAlamat);

                // Tutup modal
                const searchModal = bootstrap.Modal.getInstance(document.getElementById('searchSekolahModal'));
                searchModal.hide();

                // Reset search
                document.getElementById('modalSearchInput').value = '';
            }
        });

        // Reset modal saat dibuka
        document.getElementById('searchSekolahModal')?.addEventListener('show.bs.modal', function() {
            document.getElementById('modalSearchInput').value = '';
            document.getElementById('searchResults').innerHTML = `
            <div class="text-center text-muted">
                <i class="ri-search-line fs-4"></i>
                <p class="mt-2">Masukkan kata kunci untuk mencari sekolah</p>
            </div>`;
        });

        // ============================================
        // 4. LOGIN FORM
        // ============================================

        document.getElementById('login-form')?.addEventListener('submit', function(e) {
            e.preventDefault();

            const nip = document.getElementById('nip').value.trim();
            const token = document.getElementById('tokenInput').value.trim();
            const kegiatan_id = document.getElementById('kegiatan_id').value;

            // Validasi NIP
            if (nip.length !== 18) {
                showAlert('error', 'Kesalahan', 'NIP harus terdiri dari 18 digit angka!');
                return false;
            }

            // Show loading
            const submitBtn = document.getElementById('submitBtn');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="ri-loader-4-line me-2"></i> MEMPROSES...';
            submitBtn.disabled = true;

            // Send AJAX request
            fetch("{{ route('lockscreen.authenticate') }}", {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({
                        nip: nip,
                        token: token,
                        kegiatan_id: kegiatan_id
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil!',
                            text: 'Login berhasil, mengarahkan ke sistem...',
                            showConfirmButton: false,
                            timer: 1500,
                            willClose: () => {
                                window.location.href = data.redirect_url;
                            }
                        });
                    } else {
                        if (data.show_register_modal) {
                            // Show registration modal
                            document.getElementById('modal-info-text').innerHTML =
                                `NIP <strong>${data.nip}</strong> belum terdaftar dalam sistem. Silakan lengkapi data diri Anda.`;

                            document.getElementById('reg_nip').value = data.nip;
                            document.getElementById('reg_kegiatan_id').value = data.kegiatan_id;
                            document.getElementById('reg_token').value = data.token;

                            const registerModal = new bootstrap.Modal(document.getElementById('registerModal'));
                            registerModal.show();

                            // Reset form modal
                            setTimeout(() => {
                                document.getElementById('optionSekolah').checked = true;
                                document.getElementById('optionSekolah').dispatchEvent(new Event('change'));
                                document.getElementById('sekolahSelect').value = '';
                                document.getElementById('instansiInput').value = '';
                                document.getElementById('sekolahInfo').classList.add('d-none');
                                document.getElementById('kotaSelect').value = '';

                                // Reset validasi
                                document.querySelectorAll('.is-invalid').forEach(el => {
                                    el.classList.remove('is-invalid');
                                });
                            }, 100);
                        } else {
                            showAlert('error', 'Kesalahan', data.message);
                        }
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showAlert('error', 'Kesalahan', 'Terjadi kesalahan pada server. Silakan coba lagi.');
                })
                .finally(() => {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                });
        });

        // ============================================
        // 5. REGISTER FORM
        // ============================================

        document.getElementById('submit-register')?.addEventListener('click', function() {
            const form = document.getElementById('register-form');
            const formData = new FormData(form);

            // 1. Validasi required fields dasar
            const requiredFields = ['nama', 'jenis_kelamin', 'tempat_lahir', 'tgl_lahir', 'pangkat_jabatan_id', 'email', 'no_hp'];
            let isValid = true;
            let errorMessages = [];

            // Reset semua validasi
            document.querySelectorAll('.is-invalid').forEach(el => {
                el.classList.remove('is-invalid');
            });

            // Validasi field dasar
            requiredFields.forEach(field => {
                const input = form.querySelector(`[name="${field}"]`);
                if (!input.value.trim()) {
                    isValid = false;
                    input.classList.add('is-invalid');
                    let fieldName = field.replace('_', ' ');
                    fieldName = fieldName.charAt(0).toUpperCase() + fieldName.slice(1);
                    errorMessages.push(`${fieldName} wajib diisi`);
                }
            });

            // 2. Validasi Kota
            const kotaSelect = document.getElementById('kotaSelect');
            if (!kotaSelect.value) {
                isValid = false;
                errorMessages.push('Pilih kota');
                kotaSelect.classList.add('is-invalid');
            }

            // 3. Validasi Sekolah/Instansi
            const sekolahOption = document.querySelector('input[name="sekolah_option"]:checked');
            if (!sekolahOption) {
                isValid = false;
                errorMessages.push('Pilih opsi sekolah atau input manual');
            } else if (sekolahOption.value === 'sekolah') {
                // Validasi pilih sekolah dari dropdown
                const sekolahSelect = document.getElementById('sekolahSelect');
                if (!sekolahSelect.value) {
                    isValid = false;
                    errorMessages.push('Pilih sekolah dari daftar');
                    sekolahSelect.classList.add('is-invalid');
                } else {
                    // Pastikan sekolah_id ada di formData
                    formData.set('sekolah_id', sekolahSelect.value);
                    formData.delete('instansi'); // Hapus instansi jika sekolah dipilih
                }
            } else if (sekolahOption.value === 'manual') {
                // Validasi input manual instansi
                const instansiInput = document.getElementById('instansiInput');
                if (!instansiInput.value.trim()) {
                    isValid = false;
                    errorMessages.push('Isi nama instansi/lembaga');
                    instansiInput.classList.add('is-invalid');
                } else {
                    // Pastikan instansi ada di formData
                    formData.set('instansi', instansiInput.value);
                    formData.delete('sekolah_id'); // Hapus sekolah_id jika manual dipilih
                }
            }

            // 4. Validasi Email
            const emailInput = form.querySelector('[name="email"]');
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (emailInput.value.trim() && !emailRegex.test(emailInput.value.trim())) {
                isValid = false;
                emailInput.classList.add('is-invalid');
                errorMessages.push('Format email tidak valid');
            }

            // 5. Validasi Nomor HP
            const phoneInput = form.querySelector('[name="no_hp"]');
            const phoneValue = phoneInput.value.replace(/\D/g, '');
            if (phoneInput.value.trim() && phoneValue.length < 10) {
                isValid = false;
                phoneInput.classList.add('is-invalid');
                errorMessages.push('Nomor HP minimal 10 digit');
            }

            // 6. Validasi Tanggal Lahir (minimal 17 tahun)
            const dobInput = form.querySelector('[name="tgl_lahir"]');
            if (dobInput.value) {
                const dob = new Date(dobInput.value);
                const today = new Date();
                const minAgeDate = new Date(today.getFullYear() - 17, today.getMonth(), today.getDate());

                if (dob > minAgeDate) {
                    isValid = false;
                    dobInput.classList.add('is-invalid');
                    errorMessages.push('Minimal usia 17 tahun');
                }
            }

            // Tampilkan error jika ada
            if (!isValid) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Data Belum Lengkap',
                    html: 'Harap lengkapi data berikut:<br><br>' + errorMessages.join('<br>'),
                    confirmButtonText: 'Mengerti',
                    confirmButtonColor: '#2c7be5'
                });
                return;
            }

            // 7. Kirim data ke server
            Swal.fire({
                title: 'Menyimpan Data...',
                text: 'Mohon tunggu sebentar',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            fetch("{{ route('lockscreen.register') }}", {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json'
                    },
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Hide modal
                        const registerModal = bootstrap.Modal.getInstance(document.getElementById('registerModal'));
                        registerModal.hide();

                        Swal.fire({
                            icon: 'success',
                            title: 'Registrasi Berhasil!',
                            text: data.message,
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#2c7be5',
                            willClose: () => {
                                document.getElementById('nip').value = data.nip;
                                document.getElementById('nip').focus();
                            }
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Registrasi Gagal',
                            text: data.message || 'Terjadi kesalahan saat menyimpan data',
                            confirmButtonText: 'Mengerti',
                            confirmButtonColor: '#dc3545'
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Kesalahan Server',
                        text: 'Terjadi kesalahan pada server',
                        confirmButtonText: 'Mengerti',
                        confirmButtonColor: '#dc3545'
                    });
                });
        });

        // Clear validation on input
        document.querySelectorAll('#register-form input, #register-form select').forEach(input => {
            input.addEventListener('input', function() {
                if (this.classList.contains('is-invalid')) {
                    this.classList.remove('is-invalid');
                }
            });
        });

        // ============================================
        // 6. INITIALIZATION
        // ============================================

        // Auto focus NIP field on page load
        document.addEventListener('DOMContentLoaded', function() {
            const nipField = document.getElementById('nip');
            if (nipField) {
                nipField.focus();
            }
        });
    </script>
</body>

</html>