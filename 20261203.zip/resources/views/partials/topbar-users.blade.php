<header id="page-topbar">
    <div class="layout-width">
        <div class="navbar-header">
            <div class="d-flex">
                <!-- LOGO -->
                <div class="navbar-brand-box horizontal-logo">
                    {{-- ✅ MATIIN LINK TANPA UBAH TAMPILAN --}}
                    <a href="javascript:void(0)" onclick="return false;" class="logo logo-dark">
                        <span class="logo-sm">
                            <img src="{{asset('build')}}/images/logo-sm.png" alt="" height="15">
                        </span>
                        <span class="logo-lg" style="align-self:flex-start !important;">
                            <img src="{{asset('build')}}/images/tanparagu2.png"
                                alt=""
                                height="140"
                                style="position:relative; top:-10px;">
                        </span>
                    </a>

                    {{-- ✅ MATIIN LINK TANPA UBAH TAMPILAN --}}
                    <a href="javascript:void(0)" onclick="return false;" class="logo logo-light">
                        <span class="logo-sm">
                            <img src="{{asset('build')}}/images/logo-sm.png" alt="" height="15">
                        </span>
                        <span class="logo-lg">
                            <img src="{{asset('build')}}/images/logo-light.png" alt="" height="40">
                        </span>
                    </a>
                </div>

                <button type="button" class="btn btn-sm px-3 fs-16 header-item vertical-menu-btn topnav-hamburger material-shadow-none" id="topnav-hamburger-icon">
                    <span class="hamburger-icon">
                        <span></span>
                        <span></span>
                        <span></span>
                    </span>
                </button>

            </div>

            <div class="d-flex align-items-center">

                <div class="ms-1 header-item d-none d-sm-flex">
                    <button type="button" class="btn btn-icon btn-topbar material-shadow-none btn-ghost-secondary rounded-circle" data-toggle="fullscreen">
                        <i class='bx bx-fullscreen fs-22'></i>
                    </button>
                </div>

            </div>
        </div>
    </div>
</header>

<!-- removeNotificationModal -->
<div id="removeNotificationModal" class="modal fade zoomIn" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="NotificationModalbtn-close"></button>
            </div>
            <div class="modal-body">
                <div class="mt-2 text-center">
                    <lord-icon src="https://cdn.lordicon.com/gsqxdxog.json" trigger="loop" colors="primary:#f7b84b,secondary:#f06548" style="width:100px;height:100px"></lord-icon>
                    <div class="mt-4 pt-2 fs-15 mx-4 mx-sm-5">
                        <h4>Are you sure ?</h4>
                        <p class="text-muted mx-4 mb-0">Are you sure you want to remove this Notification ?</p>
                    </div>
                </div>
                <div class="d-flex gap-2 justify-content-center mt-4 mb-2">
                    <button type="button" class="btn w-sm btn-light" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn w-sm btn-danger" id="delete-notification">Yes, Delete It!</button>
                </div>
            </div>

        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

{{-- ✅ AKTIFIN FULLSCREEN TANPA UBAH TAMPILAN --}}
<script>
document.addEventListener("DOMContentLoaded", function () {
    const btn = document.querySelector('[data-toggle="fullscreen"]');
    if (!btn) return;

    function openFullscreen() {
        const el = document.documentElement;
        if (el.requestFullscreen) return el.requestFullscreen();
        if (el.webkitRequestFullscreen) return el.webkitRequestFullscreen(); // Safari
        if (el.mozRequestFullScreen) return el.mozRequestFullScreen(); // Firefox
        if (el.msRequestFullscreen) return el.msRequestFullscreen(); // IE/Edge lama
    }

    function closeFullscreen() {
        if (document.exitFullscreen) return document.exitFullscreen();
        if (document.webkitExitFullscreen) return document.webkitExitFullscreen(); // Safari
        if (document.mozCancelFullScreen) return document.mozCancelFullScreen(); // Firefox
        if (document.msExitFullscreen) return document.msExitFullscreen(); // IE/Edge lama
    }

    btn.addEventListener("click", function (e) {
        e.preventDefault();

        const isFull =
            document.fullscreenElement ||
            document.webkitFullscreenElement ||
            document.mozFullScreenElement ||
            document.msFullscreenElement;

        if (!isFull) openFullscreen();
        else closeFullscreen();
    });
});
</script>
