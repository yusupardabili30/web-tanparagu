<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PtkJawaban extends Model
{
    use HasFactory;

    protected $table = 'ptk_jawaban';
    protected $primaryKey = 'ptk_jawaban_id';
    public $timestamps = true;

    protected $fillable = [
        'kegiatan_id',
        'tahap',
        'ptk_id',
        'instrumen_id',
        'indikator_id',
        'indikator_code',
        'sub_indikator_id',
        'sub_indikator_code',
        'level',
        'bobot',
        'selisih',
        'time_start',
        'time_end',
        'created_at',
        'updated_at'
    ];
}
