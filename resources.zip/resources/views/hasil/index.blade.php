@extends('layouts.main')
@section('mycontent')
@php
    $tittle = $tittle ?? 'Hasil Instrumen PTK';
    $kegiatans = DB::table('kegiatan')->get();

    $levelNames = [
        2 => 'Penerapan',
        3 => 'Analisis',
        4 => 'Evaluasi',
        5 => 'Pembimbingan'
    ];

    $levelColors = [
        2 => 'info',
        3 => 'primary',
        4 => 'warning',
        5 => 'success'
    ];

    // ✅ Grouping per NIP (di page ini saja, karena paginator)
    $groups = $data->getCollection()->groupBy(function($r){
        return (string)($r->nip ?? 'tanpa_nip');
    });
@endphp

<style>
    :root{
        --mm-blue:#1a4d8e;
        --mm-soft:#f6f9ff;
        --mm-text:#1f2937;
        --mm-muted:#6b7280;
        --mm-line:#e5e7eb;
        --mm-card:#ffffff;
        --mm-shadow: 0 10px 24px rgba(17,24,39,.10);
        --mm-shadow2: 0 6px 16px rgba(26,91,184,.12);
        --radius: 16px;
    }

    .hi-wrap{
        background: #f3f7ff;
        border-radius: 18px;
        padding: 18px;
    }

    /* =========================
       HEADER PAGE
       ========================= */
    .hi-head{
        position: relative;
        overflow: hidden;
        border-radius: 22px;
        padding: 22px 24px;
        margin-bottom: 14px;
        background: var(--mm-blue);
        border: 1px solid rgba(255,255,255,.20);
        box-shadow: 0 10px 24px rgba(17,24,39,.12);
    }
    .hi-head::before{
        content:"";
        position:absolute;
        inset:0;
        background-image: url("{{ asset('build/images/baduy.jpg') }}");
        background-repeat: repeat;
        background-size: 140px auto;
        background-position: center;
        opacity: .55;
        filter: grayscale(100%) contrast(1.15);
        z-index: 0;
    }
    .hi-head::after{
        content:"";
        position:absolute;
        inset:0;
        background: rgba(26,91,184,.45);
        z-index: 1;
    }
    .hi-head > *{ position: relative; z-index: 2; }
    .hi-head, .hi-head *{ color:#fff !important; }

    .hi-head h5{
        margin:0;
        font-size: 18px !important;
        font-weight: 900;
        letter-spacing:.2px;
        text-shadow: 0 2px 12px rgba(0,0,0,.35) !important;
    }
    .hi-head .meta{
        font-size: 12.5px;
        opacity: .95;
        margin-top: 6px;
        color: rgba(255,255,255,.92) !important;
        text-shadow: 0 2px 12px rgba(0,0,0,.35) !important;
    }

    .hi-title-icon{
        width: 40px;
        height: auto;
        border-radius: 12px;
        color: #fff !important;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        flex: 0 0 auto;
        backdrop-filter: blur(6px);
    }
    .hi-title-icon i{ font-size: 18px; }

    /* =========================
       FILTER
       ========================= */
    .hi-filter{
        border-radius: var(--radius);
        background: var(--mm-card);
        border: 1px solid rgba(229,231,235,.9);
        box-shadow: 0 6px 18px rgba(17,24,39,.06);
        padding: 14px;
        margin-bottom: 14px;
    }
    .hi-filter .form-label{
        font-weight: 800;
        color: var(--mm-text);
        margin-bottom: 6px;
        font-size: 13px;
    }
    .hi-filter .form-control,
    .hi-filter .form-select{
        border-radius: 12px;
        height: 44px;
        font-weight: 500;
    }
    .hi-filter .btn{
        border-radius: 14px;
        height: 44px;
        font-weight: 900;
    }
    .btn-cari{
        background: #1a4d8e !important;
        border-color: #1a4d8e !important;
        color: #fff !important;
    }
    .btn-cari:hover{
        background: #163f74 !important;
        border-color: #163f74 !important;
        color: #fff !important;
    }
    .btn-cari:focus{
        box-shadow: 0 0 0 .25rem rgba(26,91,184,.25) !important;
    }
    .btn-export-pill{
        border-radius: 18px !important;
        padding: 12px 18px !important;
        font-weight: 900 !important;
        box-shadow: 0 10px 18px rgba(0,0,0,.10);
    }

    /* =========================
       LIST PER PTK
       ========================= */
    .hi-list{ display:flex; flex-direction:column; gap:14px; }

    .ptk-card{
        border-radius: 18px;
        background: #fff;
        border: 1px solid rgba(229,231,235,.95);
        box-shadow: var(--mm-shadow);
        overflow: hidden;
    }

    /* =========================
       ✅ PROFIL CARD (NAMA JADI CARD)
       ========================= */
    .ptk-head{
        padding: 14px;
        background: #fff;
        border-bottom: 1px solid rgba(229,231,235,.9);
    }

    .ptk-profile{
        border: 1px solid rgba(229,231,235,.95);
        background: #f6f9ff;
        border-radius: 16px;
        padding: 14px;
        display: flex;
        gap: 12px;
        align-items: flex-start;
    }

    .ptk-avatar{
        width: 44px;
        height: 44px;
        border-radius: 999px;
        background: rgba(26,91,184,.12);
        display: flex;
        align-items: center;
        justify-content: center;
        flex: 0 0 auto;
        color: var(--mm-blue);
    }
    .ptk-avatar i{ font-size: 20px; }

    .ptk-profile-body{ flex: 1; min-width: 0; }

    .ptk-name{
        font-size: 18px;
        font-weight: 900;
        color: var(--mm-text);
        margin: 0 0 8px 0;
        line-height: 1.2;
        word-break: break-word;
    }

    .ptk-lines{
        display: flex;
        flex-direction: column;
        gap: 6px;
        font-size: 14px;
    }

    .ptk-line{
        display: flex;
        gap: 10px;
        align-items: baseline;
        flex-wrap: wrap;
    }
    .ptk-line .k{
        width: 90px;
        color: var(--mm-muted);
        font-weight: 800;
    }
    .ptk-line .v{
        color: var(--mm-text);
        font-weight: 800;
        word-break: break-word;
        flex: 1;
        min-width: 200px;
    }

    .ptk-instansi{
        margin-top: 10px;
        color: var(--mm-muted);
        font-weight: 800;
        font-size: 12.5px;
        display: flex;
        align-items: center;
        gap: 6px;
        word-break: break-word;
    }

    /* BODY indikator 1 card */
    .ptk-body{
        padding: 14px;
    }

    .indikator-card{
        border: 1px solid rgba(229,231,235,.95);
        border-radius: 16px;
        background: #fff;
        overflow: hidden;
    }
    .indikator-card .head{
        padding: 12px 14px;
        background: var(--mm-soft);
        border-bottom: 1px solid rgba(229,231,235,.9);
        display:flex;
        justify-content: space-between;
        align-items:center;
        gap: 10px;
        flex-wrap: wrap;
    }
    .indikator-card .head .ttl{
        font-weight: 900;
        color: var(--mm-text);
        margin: 0;
        display:flex;
        align-items:center;
        gap: 8px;
    }
    .indikator-card .head .count{
        color: var(--mm-muted);
        font-weight: 900;
        font-size: 12px;
        white-space: nowrap;
    }

    /* Baris indikator */
    .indikator-row{
        padding: 12px 14px;
        border-top: 1px dashed rgba(229,231,235,.9);
    }
    .indikator-row:first-child{ border-top: none; }

    .indikator-grid{
        display:grid;
        grid-template-columns: 80px 250px 1.1fr 1.4fr;
        gap: 12px;
        align-items: start;
    }
    @media (max-width: 1200px){
        .indikator-grid{ grid-template-columns: 1fr; }
        .ptk-line .k{ width: 110px; }
        .ptk-line .v{ min-width: 0; }
    }

    .cell-title{
        font-weight: 900;
        color: var(--mm-muted);
        font-size: 12px;
        margin-bottom: 6px;
    }

    /* Nomor */
    .no-box{
        width: 52px;
        height: 52px;
        border-radius: 16px;
        background: rgba(26,91,184,.12);
        color: var(--mm-blue);
        display:flex;
        align-items:center;
        justify-content:center;
        font-weight: 900;
        font-size: 14px;
    }

    /* Level box */
    .lv-box{
        border: 1px solid rgba(229,231,235,.95);
        background: var(--mm-soft);
        border-radius: 14px;
        padding: 10px;
    }
    .lv-sub{
        color: var(--mm-muted);
        font-weight: 900;
        font-size: 12px;
        margin-top: 10px;
        display:flex;
        align-items:center;
        gap: 6px;
    }
    .lv-badges{ display:flex; flex-wrap:wrap; gap:8px; margin-top: 8px; }

    /* Indikator box */
    .ind-box{
        border: 1px solid rgba(229,231,235,.95);
        background: #fff;
        border-radius: 14px;
        padding: 10px;
    }
    .ind-name{
        font-weight: 900;
        color: var(--mm-text);
        font-size: 13.5px;
        line-height: 1.25;
        margin-bottom: 6px;
    }
    .ind-code{
        color: var(--mm-muted);
        font-weight: 800;
        font-size: 12px;
        display:flex;
        align-items:center;
        gap: 8px;
    }

    /* Rekomendasi */
    .rek-box{
        border: 1px solid rgba(229,231,235,.95);
        background: #fff;
        border-radius: 14px;
        padding: 10px;
    }
    .rek-item{
        border-radius: 12px;
        border: 1px solid rgba(229,231,235,.95);
        background: var(--mm-soft);
        padding: 10px;
    }
    .rek-item + .rek-item{ margin-top: 10px; }
    .rek-top{
        display:flex;
        justify-content: space-between;
        align-items:flex-start;
        gap: 10px;
        margin-bottom: 6px;
    }
    .rek-desc{
        color: var(--mm-text);
        font-weight: 500;
        font-size: 12.5px;
        line-height: 1.35;
    }

    .page-link{ border-radius: 10px !important; font-weight: 800; }












     /* =========================
       PELATIHAN STYLE
       ========================= */
    .pelatihan-section {
        margin-top: 12px;
        border-top: 1px dashed rgba(229,231,235,.7);
        padding-top: 12px;
    }

    .pelatihan-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: rgba(26,91,184,.08);
        border: 1px solid rgba(26,91,184,.2);
        color: var(--mm-blue);
        border-radius: 10px;
        padding: 6px 12px;
        font-size: 12px;
        font-weight: 800;
        margin-right: 8px;
        margin-bottom: 8px;
    }

    .pelatihan-badge i {
        font-size: 14px;
    }

    .pelatihan-kategori {
        font-size: 11px;
        color: var(--mm-muted);
        font-weight: 800;
        display: block;
        margin-top: 4px;
    }

    .no-pelatihan {
        color: var(--mm-muted);
        font-style: italic;
        font-size: 12.5px;
        font-weight: 500;
    }
</style>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Daftar {{ $tittle }}</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">{{ $tittle }}</a></li>
                        <li class="breadcrumb-item active">Daftar {{ $tittle }}</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="hi-wrap">
        <div class="hi-head d-flex align-items-center justify-content-between flex-wrap gap-2">
            <div>
                <h5 class="mb-0 d-flex align-items-center gap-2">
                    <span class="hi-title-icon"><i class="ri-bar-chart-2-line"></i></span>
                    {{ $tittle }}
                </h5>
                <div class="meta">
                    @if($data->isNotEmpty())
                        Menampilkan {{ $data->total() }} data
                    @else
                        Tidak ada data
                    @endif
                </div>
            </div>
        </div>

        {{-- FILTER --}}
        <div class="hi-filter">
            <form action="{{ route('hasil-instrumen.index') }}" method="GET" class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label">Pencarian</label>
                    <input type="text" class="form-control" name="search"
                           value="{{ request('search') }}"
                           placeholder="Cari Nama/NIP PTK/Sub Indikator...">
                </div>

                <div class="col-md-3">
                    <label class="form-label">Kegiatan</label>
                    <select class="form-select" name="kegiatan_id">
                        <option value="">Semua Kegiatan</option>
                        @foreach($kegiatans as $kegiatan)
                            <option value="{{ $kegiatan->kegiatan_id }}"
                                {{ request('kegiatan_id') == $kegiatan->kegiatan_id ? 'selected' : '' }}>
                                {{ $kegiatan->kegiatan_name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Tahap</label>
                    <select class="form-select" name="tahap">
                        <option value="">Semua Tahap</option>
                        @for($i = 1; $i <= 10; $i++)
                            <option value="{{ $i }}" {{ request('tahap') == $i ? 'selected' : '' }}>
                                Tahap {{ $i }}
                            </option>
                        @endfor
                    </select>
                </div>

                <div class="col-md-2">
                    @if($data->isNotEmpty())
                        <div class="w-100 mb-2">
                            <a class="btn btn-success w-100 btn-export-pill"
                               href="{{ route('hasil-instrumen.export-all', request()->query()) }}">
                                <i class="ri-file-pdf-line align-bottom me-1"></i> Export PDF
                            </a>
                        </div>
                    @endif

                    <button type="submit" class="btn btn-primary w-100 btn-cari">
                        <i class="ri-search-line align-bottom me-1"></i> Cari
                    </button>
                </div>
            </form>
        </div>

        {{-- EMPTY --}}
        @if($data->isEmpty())
            <div class="alert alert-info mb-0">
                @if(request()->hasAny(['search', 'kegiatan_id', 'tahap']))
                    Tidak ada data ditemukan dengan filter yang diterapkan.
                @else
                    Tidak ada data ditemukan.
                @endif
            </div>
        @else

            {{-- ALERT FILTER --}}
            @if(request()->hasAny(['search', 'kegiatan_id', 'tahap']))
                <div class="alert alert-info alert-dismissible fade show mb-3" role="alert">
                    <i class="ri-information-line me-2"></i>
                    Menampilkan {{ $data->total() }} data
                    @if(request('search'))
                        dengan pencarian: "<strong>{{ request('search') }}</strong>"
                    @endif
                    @if(request('kegiatan_id'))
                        | Kegiatan:
                        <strong>{{ $kegiatans->where('kegiatan_id', request('kegiatan_id'))->first()->kegiatan_name ?? '' }}</strong>
                    @endif
                    @if(request('tahap'))
                        | Tahap: <strong>{{ request('tahap') }}</strong>
                    @endif
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            @endif

            {{-- ✅ GLOBAL COUNTER BIAR NOMOR LANJUT ANTAR HALAMAN --}}
            @php
                $globalNo = $data->firstItem() ?? 1;
            @endphp

            {{-- ✅ LIST PER PTK --}}
            <div class="hi-list">
                @foreach($groups as $nipKey => $rows)
                    @php
                        $first = $rows->first();

                        $infoFirstRaw = $first->rekomendasi_info ?? [];
                        if (is_string($infoFirstRaw)) {
                            $infoFirst = json_decode($infoFirstRaw, true) ?: [];
                        } elseif (is_object($infoFirstRaw)) {
                            $infoFirst = (array) $infoFirstRaw;
                        } elseif ($infoFirstRaw instanceof \Illuminate\Support\Collection) {
                            $infoFirst = $infoFirstRaw->toArray();
                        } elseif (is_array($infoFirstRaw)) {
                            $infoFirst = $infoFirstRaw;
                        } else {
                            $infoFirst = [];
                        }

                        $jenjang = $first->jenjang_jabatan ?? '-';
                        $levelMinFirst = (int)($infoFirst['level_min'] ?? 0);
                        $levelMaxFirst = (int)($infoFirst['level_max'] ?? 0);
                    @endphp

                    <div class="ptk-card">

                        {{-- ✅ IDENTITAS SEKALI (JADI CARD PROFIL) --}}
                        <div class="ptk-head">
                            <div class="ptk-profile">
                                <div class="ptk-avatar">
                                    <i class="ri-user-3-line"></i>
                                </div>

                                <div class="ptk-profile-body">
                                    <div class="ptk-name">{{ $first->nama }}</div>

                                    <div class="ptk-lines">
                                        <div class="ptk-line">
                                            <div class="k">NIP</div>
                                            <div class="v">{{ $first->nip }}</div>
                                        </div>

                                        <div class="ptk-line">
                                            <div class="k">Jenjang</div>
                                            <div class="v">{{ $jenjang }}</div>
                                        </div>

                                        <div class="ptk-line">
                                            <div class="k">Target</div>
                                            <div class="v">Level {{ $levelMinFirst }} – {{ $levelMaxFirst }}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

  {{-- ✅ TAMBAHKAN SECTION PELATIHAN --}}
                            @if(isset($first->pelatihan) && $first->pelatihan->count() > 0)
                                <div class="pelatihan-section">
                                    <div style="margin-bottom: 8px; color: var(--mm-text); font-weight: 900; font-size: 13px;">
                                        <i class="ri-book-open-line me-1"></i> Pelatihan yang Anda Perlukan
                                    </div>
                                    <div>
                                        @foreach($first->pelatihan as $pelatihan)
                                            <div class="pelatihan-badge">
                                                <i class="ri-checkbox-circle-fill"></i>
                                                <span>{{ $pelatihan->nama_pelatihan_lengkap }}</span>
                                                <span class="pelatihan-kategori">{{ $pelatihan->kategori_pelatihan }}</span>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            @else
                                <div class="pelatihan-section">
                                    <div class="no-pelatihan">
                                        <i class="ri-information-line me-1"></i> Belum ada data pelatihan
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>


                        {{-- ✅ SEMUA INDIKATOR JADI 1 CARD --}}
                        <div class="ptk-body">
                            <div class="indikator-card">
                                <div class="head">
                                    <p class="ttl mb-0"><i class="ri-list-check-2"></i> Indikator & Rekomendasi</p>
                                    <div class="count">{{ $rows->count() }} indikator (di halaman ini)</div>
                                </div>

                                @foreach($rows->values() as $idx => $row)
                                    @php
                                        $infoRaw = $row->rekomendasi_info ?? [];
                                        if (is_string($infoRaw)) {
                                            $info = json_decode($infoRaw, true) ?: [];
                                        } elseif (is_object($infoRaw)) {
                                            $info = (array) $infoRaw;
                                        } elseif ($infoRaw instanceof \Illuminate\Support\Collection) {
                                            $info = $infoRaw->toArray();
                                        } elseif (is_array($infoRaw)) {
                                            $info = $infoRaw;
                                        } else {
                                            $info = [];
                                        }

                                        $levelJawaban = (int)($row->level_jawaban ?? 0);
                                        $levelMin = (int)($info['level_min'] ?? 0);
                                        $levelMax = (int)($info['level_max'] ?? 0);

                                        $rekomendasiGap = $info['rekomendasi_gap'] ?? [];
                                        if (is_string($rekomendasiGap)) {
                                            $rekomendasiGap = json_decode($rekomendasiGap, true) ?: [];
                                        } elseif (is_object($rekomendasiGap)) {
                                            $rekomendasiGap = (array) $rekomendasiGap;
                                        } elseif (!is_array($rekomendasiGap)) {
                                            $rekomendasiGap = [];
                                        }

                                        // ✅ NOMOR GLOBAL: lanjut antar halaman
                                        $nomor = $globalNo;
                                        $globalNo++;

                                        $cid = 'rek_' . preg_replace('/[^a-zA-Z0-9]/', '', (string)($row->nip ?? 'x')) . '_' . $idx;
                                    @endphp

                                    <div class="indikator-row">
                                        <div class="indikator-grid">

                                            {{-- NOMOR --}}
                                            <div>
                                                <div class="cell-title">Nomor</div>
                                                <div class="no-box">{{ $nomor }}</div>
                                            </div>

                                            {{-- LEVEL (DICAPAI + HARUS) --}}
                                            <div>
                                                <div class="cell-title">Level yang dicapai</div>

                                                <div class="lv-box">
                                                    @if($levelJawaban > 0)
                                                        <span class="badge bg-{{ $levelColors[$levelJawaban] ?? 'secondary' }}-subtle text-{{ $levelColors[$levelJawaban] ?? 'secondary' }}"
                                                              style="border-radius:999px; padding:8px 12px; font-weight:900;">
                                                            Level {{ $levelJawaban }}
                                                        </span>
                                                        <div class="mt-2" style="color:var(--mm-muted); font-weight:800; font-size:12px;">
                                                            {{ $levelNames[$levelJawaban] ?? '' }}
                                                        </div>
                                                    @else
                                                        <span class="badge bg-secondary"
                                                              style="border-radius:999px; padding:8px 12px; font-weight:900;">-</span>
                                                    @endif

                                                    <div class="lv-sub">
                                                        <i class="ri-flag-line"></i>
                                                        <span>Level yang harus</span>
                                                    </div>

                                                    <div class="lv-badges">
                                                        @for($i = $levelMin; $i <= $levelMax; $i++)
                                                            <span class="badge bg-{{ $levelColors[$i] ?? 'secondary' }}-subtle text-{{ $levelColors[$i] ?? 'secondary' }}"
                                                                  style="border-radius:999px; padding:8px 12px; font-weight:900;">
                                                                Lv {{ $i }}
                                                            </span>
                                                        @endfor
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- INDIKATOR --}}
                                            <div>
                                                <div class="cell-title">Indikator</div>
                                                <div class="ind-box">
                                                    <div class="ind-name">{{ $row->sub_indikator_name }}</div>
                                                    <div class="ind-code">
                                                        <i class="ri-hashtag"></i>
                                                        <span>Kode: <strong>{{ $row->sub_indikator_code }}</strong></span>
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- REKOMENDASI GAP --}}
                                            <div>
                                                <div class="cell-title">Rekomendasi GAP</div>
                                                <div class="rek-box">
                                                    @if(count($rekomendasiGap) > 0)
                                                        @foreach($rekomendasiGap as $rkIndex => $rek)
                                                            @php
                                                                $rekLevel = (int)($rek['level'] ?? 0);
                                                                $rekText  = (string)($rek['rekomendasi'] ?? '');
                                                                $short    = \Illuminate\Support\Str::limit($rekText, 160);
                                                                $needMore = strlen($rekText) > 160;
                                                                $collapseId = $cid . '_' . $rkIndex;
                                                            @endphp

                                                            <div class="rek-item">
                                                                <div class="rek-top">
                                                                    <span class="badge bg-danger-subtle text-danger"
                                                                          style="border-radius:999px; font-weight:900; padding:8px 12px;">
                                                                        Gap Level {{ $rekLevel }}
                                                                    </span>
                                                                    <small class="text-muted fw-semibold">
                                                                        {{ $levelNames[$rekLevel] ?? '' }}
                                                                    </small>
                                                                </div>

                                                                <div class="rek-desc">{{ $short }}</div>

                                                                @if($needMore)
                                                                    <button type="button"
                                                                            class="btn btn-sm btn-outline-primary mt-2"
                                                                            data-bs-toggle="collapse"
                                                                            data-bs-target="#{{ $collapseId }}"
                                                                            aria-expanded="false"
                                                                            style="border-radius:10px; font-weight:900;">
                                                                        Selengkapnya
                                                                    </button>
                                                                    <div class="collapse mt-2" id="{{ $collapseId }}">
                                                                        <div class="small text-muted fw-semibold" style="line-height:1.35;">
                                                                            {{ $rekText }}
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                            </div>
                                                        @endforeach
                                                    @else
                                                        <div class="text-center p-2">
                                                            <span class="badge bg-success-subtle text-success px-3 py-2"
                                                                  style="border-radius:999px; font-weight:900;">
                                                                <i class="ri-check-line me-1"></i> Memenuhi standar kompetensi jabatan
                                                            </span>
                                                        </div>
                                                    @endif
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                @endforeach

                            </div>
                        </div>

                    </div>
                @endforeach
            </div>

            <div class="mt-3">
                {!! $data->withQueryString()->links('pagination::bootstrap-5') !!}
            </div>
        @endif
    </div>
</div>
@endsection

@section('sipproja-js')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
</script>
@endsection
